# !/urs/bin/python3
#-*- coding: utf-8 -*-

import sys
import pandas as pd
from PyQt5.QtWidgets import QApplication, QWidget
from PyQt5 import uic, QtWidgets, QtCore, QtWebEngineWidgets, QtGui
import bin_utils as modul
import pyqtgraph as pg
import datetime
import BinScreener as screener
# from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg

connection = modul.connect_to_sqlalchemy()
tf_5m = 5 * 60
tf_1h = 60 * 60
red_pen = pg.mkPen(color=(255, 0, 0))
blue_pen = pg.mkPen(color=(0, 0, 255))
green_pen = pg.mkPen(color=(0, 128, 0))
orange_pen = pg.mkPen(color=(255, 140, 0))

# class my_canvas(FigureCanvasQTAgg):
#     def __init__(self, fig):
class CandlestickItem(pg.GraphicsObject):
    def __init__(self, data):
        pg.GraphicsObject.__init__(self)
        self.df = data
        self.generatePicture()

    def generatePicture(self):
        self.picture = QtGui.QPicture()
        p = QtGui.QPainter(self.picture)

        for i in range(len(self.df)):
            index = self.df.index[i]
            time = self.df.loc[index]['startTime']
            open = self.df.loc[index]['open']
            high = self.df.loc[index]['high']
            low = self.df.loc[index]['low']
            close = self.df.loc[index]['close']

            if close >= open:
                p.setPen(green_pen)
                p.setBrush(pg.mkBrush(color=(0, 128, 0)))
            else:
                p.setPen(red_pen)
                p.setBrush(pg.mkBrush(color=(255, 0, 0)))

            p.drawLine(QtCore.QPointF(i, high), QtCore.QPointF(i, low))
            p.drawRect(QtCore.QRectF(i-0.25, open, 0.5, close-open))
        p.end()

    def paint(self, p, *args):
        p.drawPicture(0, 0, self.picture)

    def boundingRect(self):
        return QtCore.QRectF(self.picture.boundingRect())


class App(QWidget):
    def __init__(self):
        super().__init__()
        self.start()
        self.refresh_opened()
        self.refresh_screened()
        self.refresh_checked()
        self.set()

    def start(self):
        self.ui = uic.loadUi('main_window.ui')
        self.ui.show()

    def set(self):
        # Tab Trading
        self.ui.ButtonShortLim.clicked.connect(lambda: self.click_short(True))
        self.ui.ButtonLongLim.clicked.connect(lambda: self.click_long(True))
        self.ui.ButtonShortMar.clicked.connect(lambda: self.click_short(False))
        self.ui.ButtonLongMar.clicked.connect(lambda: self.click_long(False))
        self.ui.ButtonCloseLim.clicked.connect(lambda: self.click_close(True))
        self.ui.ButtonCloseMar.clicked.connect(lambda: self.click_close(False))
        self.ui.deletePairButton.clicked.connect(self.delete_selected_pair)
        self.ui.updateOpenButton.clicked.connect(self.refresh_opened)
        self.ui.updateCheckButton.clicked.connect(self.refresh_checked)
        self.ui.newStatsButton.clicked.connect(self.update_stats_for_check)
        self.ui.upButton.clicked.connect(lambda: self.update_open_levels('up'))
        self.ui.downButton.clicked.connect(lambda: self.update_open_levels('down'))
        self.ui.stopButton.clicked.connect(lambda: self.update_open_levels('stop'))
        self.ui.upButtonCheck.clicked.connect(lambda: self.update_check_levels('up'))
        self.ui.downButtonCheck.clicked.connect(lambda: self.update_check_levels('down'))
        self.ui.tradingOpenPos.selectionModel().selectionChanged.connect(self.opened_pair_clicked)
        self.ui.tradingForCheck.selectionModel().selectionChanged.connect(self.for_check_pair_clicked)
        self.ui.openInTVtrading.clicked.connect(self.open_trading_in_tview)
        # Tab Screener
        self.ui.setConfirm.clicked.connect(self.add_to_check)
        self.ui.updRowScrnButton.clicked.connect(self.refresh_screened)
        self.ui.openInTV.clicked.connect(self.open_screen_in_tview)
        self.ui.updateScreening.clicked.connect(self.update_screening)
        self.ui.tableScreen.selectionModel().selectionChanged.connect(self.selected_pair_clicked)

        self.ui.scrPlot_5m.setBackground('w')
        self.ui.plotWidget.setBackground('w')
        # self.ui.setLvlUp.setInputMask('00000.00000')
        self.ui.radioButton.setChecked(True)
        self.ui.radioScreen_2.setChecked(True)
        self.ui.posSize.setText('30.0')

    def click_short(self, limit):
        new_row = self.ui.tradingForCheck.currentRow()
        pair1 = self.ui.tradingForCheck.item(new_row, 0).text()
        try:
            pair = self.ui.textPairTrade.text()
            if pair != pair1:
                print("Убедитесь, что выбранная пара соответствует активной строке")
                return False
        except:
            print("Выберите пару для торговли!")
            return False
        coin1,coin2 = modul.pair_to_coins(pair)
        going_to = "DOWN"
        amount = float(self.ui.posSize.text())
        strategy = self.ui.tradingForCheck.item(new_row, 9).text()
        lookback = 240
        up = float(self.ui.tradingForCheck.item(new_row, 1).text())
        down = float(self.ui.tradingForCheck.item(new_row, 2).text())
        modul.open_pair_position(connection, coin1, coin2, going_to, amount, lookback, stop=0.0,
                       limit=limit, strategy=strategy, up_from=up, down_to=down,
                       use_sql_for_report = True)
        self.refresh_opened()

    def click_long(self, limit):
        new_row = self.ui.tradingForCheck.currentRow()
        pair1 = self.ui.tradingForCheck.item(new_row, 0).text()

        try:
            pair = self.ui.textPairTrade.text()
            if pair != pair1:
                print("Убедитесь, что выбранная пара соответствует активной строке")
                return False
        except:
            print("Выберите пару для торговли!")
            return False
        coin1,coin2 = modul.pair_to_coins(pair)
        going_to = "UP"
        amount = float(self.ui.posSize.text())
        up = float(self.ui.tradingForCheck.item(new_row, 1).text())
        down = float(self.ui.tradingForCheck.item(new_row, 2).text())
        strategy = self.ui.tradingForCheck.item(new_row, 9).text()
        lookback = 240
        modul.open_pair_position(connection, coin1, coin2, going_to, amount, lookback, stop=0.0,
                       limit=limit, strategy=strategy, up_from=up, down_to=down,
                       use_sql_for_report = True)
        self.refresh_opened()

    def click_close(self, limit):
        pair = self.ui.textPairTrade.text()
        new_row = self.ui.tradingOpenPos.currentRow()
        pair2 = self.ui.tradingOpenPos.item(new_row, 0).text()
        if pair != pair2:
            print("Проверьте пару для закрытия! Отличается от выбранной в таблице!")
            return False
        coin1_id = int(self.ui.tradingOpenPos.item(new_row, 8).text())
        coin2_id = int(self.ui.tradingOpenPos.item(new_row, 9).text())
        size1 = float(self.ui.tradingOpenPos.item(new_row, 10).text())
        size2 = float(self.ui.tradingOpenPos.item(new_row, 11).text())
        going_to = self.ui.tradingOpenPos.item(new_row, 2).text()
        coin1, coin2 = modul.pair_to_coins(pair)
        l_price = modul.get_last_spread_price(coin1, coin2)
        try:
            stop = self.ui.tradingOpenPos.item(new_row, 3).text()
            stop = float(stop)
            if (going_to == 'UP' and l_price > stop) or (going_to == 'DOWN' and l_price < stop):
                # Значит закрываемся не по превышению стопа, значит стоп не передаем
                stop = 0.0
        except:
            stop = 0.0

        # создаем строку с данными
        df_row = pd.DataFrame({
            'coin1': [coin1],
            'coin2': [coin2],
            'going_to': [going_to],
            'cl_price': [round(l_price, 6)],
            'stop': [round(stop, 6)],
        },
            index=None)
        modul.close_pair_position(connection, coin1_id, coin2_id, coin1, coin2, size1, size2, l_price, df_row, limit)
        self.refresh_opened()

    def delete_selected_pair(self):
        new_row = self.ui.tradingForCheck.currentRow()
        pair = self.ui.tradingForCheck.item(new_row, 0).text()
        modul.delete_row_from_sql(connection, 'bin_to_check', pair)
        self.refresh_checked()

    def update_open_levels(self, up_down):

        if up_down == 'up':
            level = self.ui.upLevel.text()
            self.ui.upLevel.setText('')
        elif up_down == 'down':
            level = self.ui.downLevel.text()
            self.ui.downLevel.setText('')
        else:
            level = self.ui.stopLoss.text()
            self.ui.stopLoss.setText('')

        if level != '':
            # q_text = f'{up_down} = {level}'
            new_row = self.ui.tradingOpenPos.currentRow()
            if new_row != -1:
                coin1_id = self.ui.tradingOpenPos.item(new_row, 8).text()
                modul.update_closedf(connection,coin1_id,up_down, level)
                self.refresh_opened()
            else:
                print('Сначала выберите строку')

    def update_check_levels(self, up_down):

        if up_down == 'up':
            level = self.ui.upLvlCheck.text()
            self.ui.upLvlCheck.setText('')
        else:
            level = self.ui.downLvlCheck.text()
            self.ui.downLvlCheck.setText('')

        if level != '':
            new_row = self.ui.tradingForCheck.currentRow()
            if new_row != -1:
                pair = self.ui.tradingForCheck.item(new_row, 0).text()
                modul.update_check_df(connection,pair,up_down, level)
                self.refresh_checked()
            else:
                print('Сначала выберите строку')

    def add_to_check(self):

        try:
            pair = self.ui.textGraphPair.text()
        except:
            print("Пара не выбрана!")
            return False
        new_row = self.ui.tableScreen.currentRow()

        coint = float(self.ui.tableScreen.item(new_row, 1).text())
        stat = float(self.ui.tableScreen.item(new_row, 2).text())

        coin1, coin2 = modul.pair_to_coins(pair)

        strategy = self.ui.strategyList.currentText()
        if strategy == 'manual':
            up_text = self.ui.setLvlUp.text()
            up_text = up_text.replace(',', '.')
            set_up = float(up_text)
            down_text = self.ui.setLvlDown.text()
            down_text = down_text.replace(',', '.')
            set_down = float(down_text)
        else:
            set_up = 0.0
            set_down = 0.0

        try:
            set_lkb = int(self.ui.setLookback.text())
        except:
            set_lkb = 0
        try:
            set_stop = float(self.ui.setStopLoss.text())
        except:
            set_stop = 0.0
        try:
            set_take = float(self.ui.setTake.text())
        except:
            set_take = 0.0

        action = 'signal'
        if self.ui.radioButton_2.isChecked():
            action = 'trade'

        # добавляем пару к отслеживанию
        df_row = pd.DataFrame({
            'pair': [pair],
            'coin1': [coin1],
            'coin2': [coin2],
            'strategy': [strategy],
            'lookback': [set_lkb],
            'up': [set_up],
            'down': [set_down],
            'stop': [set_stop],
            'take': [set_take],
            'coint': [coint],
            'statio': [stat],
            'action': [action],
        },
            index=None)
        check_table = modul.create_check_table(connection)
        query = check_table.select()
        conn = connection.connect()
        check_df = pd.read_sql(sql=query, con=conn)
        test_df = check_df[check_df['pair'] == pair]
        if len(test_df) > 0:
            print(f'В таблице отслеживания уже есть пара {pair}')
        else:
            with connection.connect() as conn:
                df_row.to_sql(name='bin_to_check', con=conn, if_exists='append', index=False)
                print('запись добавлена')

        self.refresh_checked()
        self.refresh_screened()
        self.ui.setLvlUp.setText('')
        self.ui.setLvlDown.setText('')
        self.ui.setLookback.setText('')
        self.ui.setStopLoss.setText('')

    def selected_pair_clicked(self):

        new_row = self.ui.tableScreen.currentRow()
        # new_column = self.ui.tradingOpenPos.currentColumn()

        cell_value = self.ui.tableScreen.item(new_row, 0).text()
        lookback = 2000
        self.ui.textGraphPair.setText(cell_value)
        df = get_pair_marketdata(cell_value, lookback)
        max_df = df['high'].max()
        min_df = df['low'].min()
        plot_item = CandlestickItem(df)

        self.ui.scrPlot_5m.clear()
        self.ui.scrPlot_5m.enableAutoRange()
        self.ui.scrPlot_5m.addItem(plot_item)
        self.ui.scrPlot_5m.setYRange(min_df, max_df)

    def opened_pair_clicked(self):

        new_row = self.ui.tradingOpenPos.currentRow()
        if new_row != -1:
            cell_value = self.ui.tradingOpenPos.item(new_row, 0).text()
            direction = self.ui.tradingOpenPos.item(new_row, 2).text()
            buy_level = self.ui.tradingOpenPos.item(new_row, 1).text()
            strategy = self.ui.tradingOpenPos.item(new_row, 6).text()

            lookback = 2000

            self.ui.textGraphPair_2.setText(cell_value)
            self.ui.textPairTrade.setText(cell_value)

            df = get_pair_marketdata(cell_value, lookback)
            max_df = df['high'].max()
            min_df = df['low'].min()
            plot_item = CandlestickItem(df)
            self.ui.plotWidget.clear()
            self.ui.plotWidget.enableAutoRange()
            self.ui.plotWidget.addItem(plot_item)
            self.ui.plotWidget.addLine(x=None, y=buy_level, pen=blue_pen)
            if strategy == 'manual':
                if direction == 'UP':
                    take = self.ui.tradingOpenPos.item(new_row, 4).text()
                else:
                    take = self.ui.tradingOpenPos.item(new_row, 5).text()
                self.ui.plotWidget.addLine(x=None, y=take, pen=green_pen)

            try:
                stop = self.ui.tradingOpenPos.item(new_row, 3).text()
                self.ui.plotWidget.addLine(x=None, y=stop, pen=red_pen)
            except:
                pass
            self.ui.plotWidget.setYRange(min_df, max_df)
            self.ui.plotWidget.PlotDataItem(x=1, y=min_df)

    def for_check_pair_clicked(self):

        new_row = self.ui.tradingForCheck.currentRow()
        cell_value = self.ui.tradingForCheck.item(new_row, 0).text()
        try:
            up_level = self.ui.tradingForCheck.item(new_row, 1).text()
            down_level = self.ui.tradingForCheck.item(new_row, 2).text()
        except:
            up_level = 0.0
            down_level = 0.0

        lookback = 2000

        self.ui.textGraphPair_2.setText(cell_value)
        self.ui.textPairTrade.setText(cell_value)

        df = get_pair_marketdata(cell_value, lookback)
        max_df = df['high'].max()
        min_df = df['low'].min()
        plot_item = CandlestickItem(df)
        self.ui.plotWidget.clear()
        self.ui.plotWidget.enableAutoRange()
        # self.ui.plotWidget.setAutoVisible()
        self.ui.plotWidget.addItem(plot_item)
        self.ui.plotWidget.addLine(x=None, y=up_level, pen=orange_pen)
        self.ui.plotWidget.addLine(x=None, y=down_level, pen=orange_pen)
        self.ui.plotWidget.setYRange(min_df, max_df)

    def refresh_screened(self):
        # сначала заполним таблицу сырых результатов
        if self.ui.radioScreen.isChecked():
            filepath_check = r'.\screening\1_raw_result.csv'
        else:
            filepath_check = r'.\screening\3_hard_check.csv'

        screen_df = pd.read_csv(filepath_check, sep="\t")
        df_check = modul.get_selected_pairs(connection)
        df_new_screen = screen_df
        need_update = False
        row = 0
        self.ui.tableScreen.setRowCount(len(screen_df))
        self.ui.tableScreen.setHorizontalHeaderLabels(('Pair', 'Coint', 'Stat'))
        for index in range(len(screen_df)):
            pair = screen_df.iloc[index]['pair']
            df = df_check[df_check['pair'] == pair]
            if len(df) > 0:
                # Значит эта пара уже есть на отслеживании
                df_new_screen = df_new_screen[df_new_screen['pair'] != pair]
                need_update = True
            else:
                self.ui.tableScreen.setItem(row, 0, QtWidgets.QTableWidgetItem(pair))
                self.ui.tableScreen.setItem(row, 1, QtWidgets.QTableWidgetItem(str(screen_df.iloc[index]['coint'])))
                self.ui.tableScreen.setItem(row, 2, QtWidgets.QTableWidgetItem(str(screen_df.iloc[index]['stat_pair'])))
                row+=1
        self.ui.tableScreen.resizeColumnToContents(0)
        self.ui.tableScreen.resizeColumnToContents(1)
        self.ui.tableScreen.resizeColumnToContents(2)
        self.ui.tableScreen.resizeColumnToContents(3)
        self.ui.tableScreen.resizeColumnToContents(4)

        if need_update:
            df_new_screen.to_csv(filepath_check, index=False, sep="\t")

    def refresh_opened(self):
        close_df = modul.get_open_positions(connection, True)
        row = 0
        self.ui.tradingOpenPos.setRowCount(len(close_df))
        for index in range(len(close_df)):
            self.ui.tradingOpenPos.setItem(row, 0, QtWidgets.QTableWidgetItem(close_df.iloc[index]['pair']))
            self.ui.tradingOpenPos.setItem(row, 1, QtWidgets.QTableWidgetItem(str(close_df.iloc[index]['price'])))
            self.ui.tradingOpenPos.setItem(row, 2, QtWidgets.QTableWidgetItem(close_df.iloc[index]['going_to']))
            self.ui.tradingOpenPos.setItem(row, 3, QtWidgets.QTableWidgetItem(str(close_df.iloc[index]['stop'])))
            self.ui.tradingOpenPos.setItem(row, 4, QtWidgets.QTableWidgetItem(str(close_df.iloc[index]['up'])))
            self.ui.tradingOpenPos.setItem(row, 5, QtWidgets.QTableWidgetItem(str(close_df.iloc[index]['down'])))
            self.ui.tradingOpenPos.setItem(row, 6, QtWidgets.QTableWidgetItem(str(close_df.iloc[index]['strategy'])))
            self.ui.tradingOpenPos.setItem(row, 7, QtWidgets.QTableWidgetItem(str(close_df.iloc[index]['lookback'])))
            self.ui.tradingOpenPos.setItem(row, 8, QtWidgets.QTableWidgetItem(str(close_df.iloc[index]['coin1_id'])))
            self.ui.tradingOpenPos.setItem(row, 9, QtWidgets.QTableWidgetItem(str(close_df.iloc[index]['coin2_id'])))
            self.ui.tradingOpenPos.setItem(row, 10, QtWidgets.QTableWidgetItem(str(close_df.iloc[index]['size1'])))
            self.ui.tradingOpenPos.setItem(row, 11, QtWidgets.QTableWidgetItem(str(close_df.iloc[index]['size2'])))
            row+=1
        self.ui.tradingOpenPos.resizeColumnToContents(0)
        self.ui.tradingOpenPos.resizeColumnToContents(1)
        self.ui.tradingOpenPos.resizeColumnToContents(2)
        self.ui.tradingOpenPos.resizeColumnToContents(3)
        self.ui.tradingOpenPos.resizeColumnToContents(4)
        self.ui.tradingOpenPos.resizeColumnToContents(5)

    def refresh_checked(self):
        # filepath_check = r'.\reports\bin_to_check.csv'
        # check_df = pd.read_csv(filepath_check, sep="\t")
        check_df = modul.get_selected_pairs(connection)
        check_df.sort_values(by='pair', ascending=True, inplace=True, ignore_index=True)
        row = 0
        self.ui.tradingForCheck.setRowCount(len(check_df))
        for index in range(len(check_df)):
            coin1 = check_df.iloc[index]['coin1']
            coin2 = check_df.iloc[index]['coin2']
            up_level = check_df.iloc[index]['up']
            down_level = check_df.iloc[index]['down']
            zscore = check_df.iloc[index]['zscore']
            per_dev = check_df.iloc[index]['per_dev']
            per_dev_c1 = check_df.iloc[index]['per_dev_c1']
            per_dev_c2 = check_df.iloc[index]['per_dev_c2']
            l_price = check_df.iloc[index]['l_price']
            self.ui.tradingForCheck.setItem(row, 0, QtWidgets.QTableWidgetItem(str(coin1+'-'+coin2)))
            self.ui.tradingForCheck.setItem(row, 1, QtWidgets.QTableWidgetItem(str(up_level)))
            self.ui.tradingForCheck.setItem(row, 2, QtWidgets.QTableWidgetItem(str(down_level)))
            self.ui.tradingForCheck.setItem(row, 3, QtWidgets.QTableWidgetItem(str(check_df.iloc[index]['coint'])))
            self.ui.tradingForCheck.setItem(row, 4, QtWidgets.QTableWidgetItem(str(check_df.iloc[index]['statio'])))
            self.ui.tradingForCheck.setItem(row, 5, QtWidgets.QTableWidgetItem(str(per_dev)))
            self.ui.tradingForCheck.setItem(row, 6, QtWidgets.QTableWidgetItem(str(per_dev_c1)))
            self.ui.tradingForCheck.setItem(row, 7, QtWidgets.QTableWidgetItem(str(per_dev_c2)))
            self.ui.tradingForCheck.setItem(row, 8, QtWidgets.QTableWidgetItem(str(zscore)))
            self.ui.tradingForCheck.setItem(row, 9, QtWidgets.QTableWidgetItem(str(check_df.iloc[index]['strategy'])))
            # if l_price > up_level or l_price < down_level:
            #     self.ui.tradingForCheck.item(row, 0).setBackground(QtGui.QColor('#ff9c9c'))
            # else:
            #     self.ui.tradingForCheck.item(row, 0).setBackground(QtGui.QColor('#fff'))
            if per_dev > 5.0 or per_dev < -5.0:
                self.ui.tradingForCheck.item(row, 5).setBackground(QtGui.QColor('#ff9c9c'))
            else:
                self.ui.tradingForCheck.item(row, 5).setBackground(QtGui.QColor('#fff'))
            if zscore > 2.0 or zscore < -2.0:
                self.ui.tradingForCheck.item(row, 8).setBackground(QtGui.QColor('#ff9c9c'))
            else:
                self.ui.tradingForCheck.item(row, 8).setBackground(QtGui.QColor('#fff'))
            row += 1

        self.ui.tradingForCheck.resizeColumnToContents(0)
        self.ui.tradingForCheck.resizeColumnToContents(1)
        self.ui.tradingForCheck.resizeColumnToContents(2)
        self.ui.tradingForCheck.resizeColumnToContents(3)
        self.ui.tradingForCheck.resizeColumnToContents(4)
        self.ui.tradingForCheck.resizeColumnToContents(5)
        self.ui.tradingForCheck.resizeColumnToContents(6)
        self.ui.tradingForCheck.resizeColumnToContents(7)
        self.ui.tradingForCheck.resizeColumnToContents(8)

    def open_screen_in_tview(self):
        # new_row = self.ui.tableScreen.currentRow()
        # pair = self.ui.tableScreen.item(new_row, 0).text()
        pair = self.ui.textGraphPair.text()
        open_in_tradingview(pair)

    def open_trading_in_tview(self):
        pair = self.ui.textGraphPair_2.text()
        open_in_tradingview(pair)

    def update_screening(self):
        screener.get_screening_result(False, 1000)
        screener.check_parameters_stability(window=500, steps=6, shift=72, file=3, go_next=False)
        screener.summarize_history_check()
        self.refresh_screened()

    def update_stats_for_check(self):
        get_new_stats()
        self.refresh_checked()


def get_new_stats():
    end_time = datetime.datetime.now().timestamp()
    start_time = datetime.datetime.now().timestamp() - 2000 * tf_5m
    check_df = modul.get_selected_pairs(connection)
    for index in range(len(check_df)):
        pair = check_df.iloc[index]['pair']
        coin1 = check_df.iloc[index]['coin1']
        coin2 = check_df.iloc[index]['coin2']
        coint = check_df.iloc[index]['coint']
        statio = check_df.iloc[index]['statio']
        coin1_hist = modul.get_sql_history_price(coin1, connection, start_time, end_time)
        coin2_hist = modul.get_sql_history_price(coin2, connection, start_time, end_time)
        res_row = modul.get_statistics(coin1, coin2, coin1_hist, coin2_hist, False)

        coint1 = res_row.iloc[0]['coint']
        statio1 = res_row.iloc[0]['stat_pair']
        if coint != coint1:
            modul.update_check_df(connection, pair, 'coint', coint1)
        if statio != statio1:
            modul.update_check_df(connection, pair, 'statio', statio1)


def get_pair_marketdata(pair, lookback):

    coin1, coin2 = modul.pair_to_coins(pair)
    end_time = datetime.datetime.now().timestamp()
    start_time = datetime.datetime.now().timestamp() - lookback * tf_5m - tf_5m * 50
    is_index = coin1.find("indx")
    if is_index == -1:
        df_coin1 = modul.get_sql_history_price(coin1, connection, start_time, end_time)
    else:
        df_coin1 = modul.get_index_history(coin1, connection, start_time, end_time)
    df_coin2 = modul.get_sql_history_price(coin2, connection, start_time, end_time)
    df = modul.make_spread_df(df_coin1, df_coin2, True, tf_5m)
    return df


def open_in_tradingview(pair):
    coin1, coin2 = modul.pair_to_coins(pair)
    url = f'https://www.tradingview.com/chart/?symbol=BINANCE:{coin1}PERP/BINANCE:{coin2}PERP'
    QtGui.QDesktopServices.openUrl(QtCore.QUrl(url))

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = App()
    # window.show()
    app.exec_()

