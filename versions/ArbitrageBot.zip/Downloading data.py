from pathlib import Path
import pandas as pd
from os import path
import bin_utils as modul
import time
import datetime

tf_5m = 5 * 60
tf_1m = 60
tf_5m_str = '5m'
tf_1m_str = '1m'
#'LINKUSDT', 'AAVEUSDT', 'BNBUSDT', 'ATOMUSDT', 'ETHUSDT',
            # 'ADAUSDT', 'XRPUSDT', 'SOLUSDT', 'AVAXUSDT', 'TRXUSDT'
#             '1000SHIBUSDT', 'ALGOUSDT', '1000XECUSDT', 'MANAUSDT', 'REEFUSDT', 'RENUSDT', 'SPELLUSDT',
#               'AXSUSDT', 'PEOPLEUSDT', 'LINAUSDT', 'WAVESUSDT', 'HNTUSDT', 'ICPUSDT', 'NKNUSDT'
main_list = ['APEUSDT', 'SANDUSDT', '1000XECUSDT', 'MANAUSDT', 'REEFUSDT', 'RENUSDT',
              'AXSUSDT', 'PEOPLEUSDT', 'LINAUSDT', 'WAVESUSDT', 'HNTUSDT', 'ICPUSDT', 'NKNUSDT']

def fill_deep_history_from(start_time):
    """

    :param start_time:
    :return:
    """

    # all_coins = modul.get_all_futures()
    # all_futures = all_coins.id.tolist()
    # all_futures = ['DUSKUSDT', 'LINAUSDT']
    max_time = float(1000*tf_1m)
    final_time = datetime.datetime.now().timestamp()
    for future in main_list:
        s_time = start_time
        print(f'Заполняем данные по {future}')
        filename = f"{future}.csv"
        filepath = Path("files", filename)
        coin_df = pd.DataFrame()
        if path.exists(filepath):
            coin_df = pd.read_csv(filepath, sep="\t")
            if isinstance(coin_df, pd.DataFrame) and len(coin_df) > 0:
                coin_df = modul.prepare_dataframe(df=coin_df, timestamp_field="startTime", asc=False)
                while final_time > s_time:
                    time_gap = final_time - s_time
                    if time_gap > max_time:
                        time_gap = max_time
                    end_time = s_time + time_gap
                    modul.get_history_price(future, s_time, end_time, tf_1m)
                    s_time = s_time + time_gap
                    time.sleep(1)
        else:
            end_time = s_time + max_time
            modul.get_history_price(future, s_time, end_time, tf_1m)
            time.sleep(1)


def reformating_klines_df():
    for future in main_list:
        print(f'Обрабатываем файл {future}')
        filename = f"{future}.csv"
        filepath = Path("files", filename)
        if path.exists(filepath):
            coin_df = pd.read_csv(filepath, sep="\t", parse_dates=['startTime'])
            # coin_df.drop(labels=['time'], axis=1, inplace=True)
            # coin_df['pd_date'] = pd.to_datetime(coin_df['startTime'])
            coin_df['date'] = coin_df['startTime'].dt.strftime("%Y%m%d")
            coin_df['time'] = coin_df['startTime'].dt.time
            coin_df['ticker'] = future
            coin_df['per'] = 1
            coin_df['volume'] = 1
            coin_df = modul.prepare_dataframe(df=coin_df, timestamp_field="startTime", asc=True)
            # coin_df.drop(labels=['startTime'], axis=1, inplace=True)
            filename = f"{future}_1.csv"
            filepath = Path("files", filename)
            coin_df.to_csv(filepath, columns=["ticker", "per", "date", "time", "open", "high", "low", "close", "volume"], index=False,
                          sep=",")

        # блок первичного заполнения исторических данных
# start_t = datetime.datetime(2022, 1, 1, 0, 0).timestamp()
# fill_deep_history_from(start_t)
reformating_klines_df()