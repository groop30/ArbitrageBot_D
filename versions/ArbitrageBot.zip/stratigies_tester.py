import pandas as pd
import bin_utils as modul
import talib
import datetime
from os import path

tf_5m = 5 * 60

def add_result(df, result, position, time):
    # создаем строку с данными
    new_row = pd.DataFrame({
        'position': [position],
        'result': [round(result, 2)],
        'time': [time],
    },
        index=None)
    df = pd.concat([df, new_row], ignore_index=True)
    return df

def test_oc_strategy(coin1, coin2, startdate, take_file):
    # получение исходных данных
    if take_file:
        filepath_check = r'.\files\sber_sberp.csv'
        spread_df = pd.read_csv(filepath_check, sep=",")
        spread_df.drop(["bb1.dn","bb1.up","bb3.dn","bb3.up","bb4.dn","bb4.up","MA"], axis=1, inplace=True)
    else:
        connection = modul.connect_to_sqlalchemy()
        end = datetime.datetime.now().timestamp()
        df_coin1 = modul.get_sql_history_price(coin1, connection, startdate, end)
        df_coin2 = modul.get_sql_history_price(coin2, connection, startdate, end)
        spread_df = modul.make_spread_df(df_coin1, df_coin2, last_to_end=False, tf=tf_5m)

    spread_df['bb1_up'], spread_df['sma'],spread_df['bb1_down'], = talib.BBANDS(spread_df.close, 240, 1, 1, 0)
    spread_df['bb3_up'], aaa, spread_df['bb3_down'] = talib.BBANDS(spread_df.close, 240, 3, 3, 0)
    spread_df['bb4_up'], bbb, spread_df['bb4_down'] = talib.BBANDS(spread_df.close, 240, 4.2, 4.2, 0)

    # определелим переменные для расчетов
    result_df = pd.DataFrame(columns=['position', 'result', 'time'])
    inPosition = False
    first_take_close = False
    second_take_close = False
    enterShort = 0.0
    enterLong = 0.0
    stopShort = 0.0
    stopLong = 0.0
    wait_sma_cross = False
    first_stop = False
    # result = 0.0
    for index in range(len(spread_df)):
        # вынем из дф нужные данные в переменные
        close = spread_df.iloc[index]['close']
        time =  spread_df.iloc[index]['time']
        if index > 240:
            close_before = spread_df.iloc[index-1]['close']
        else:
            close_before = 0.0
        bb3_up = spread_df.iloc[index]['bb3_up']
        bb3_down = spread_df.iloc[index]['bb3_down']
        sma = spread_df.iloc[index]['sma']
        # Проверим, есть ли пересечение сма, если нам нужно его дождаться
        if wait_sma_cross:
            if (close_before < sma < close) |(close_before > sma > close):
                wait_sma_cross = False

        # сначала смотрим условия для открытия позиции
        if not inPosition and not wait_sma_cross:
            if close_before > bb3_up > close:
                # открываем позицию в шорт
                enterShort = close
                stopShort = spread_df.iloc[index]['bb4_up']
                first_stop = True
                result_df = add_result(result_df, 0.0, 'open short', time)
                inPosition = True
            elif close > bb3_down > close_before and close_before != 0:
                enterLong = close
                stopLong = spread_df.iloc[index]['bb4_down']
                first_stop = True
                result_df = add_result(result_df, 0.0, 'open long', time)
                inPosition = True
        else:
            # сначала проверяем на превышение риска
            if close > stopShort and stopShort != 0.0:
                # закрываемся
                inPosition = False
                result = (enterShort - close) / enterShort * 100
                result_df = add_result(result_df, result, 'stop loss', time)
                enterShort = stopShort = 0.0
                first_take_close = False
                second_take_close = False
                if first_stop:
                    wait_sma_cross = True
            elif close < stopLong:
                inPosition = False
                result = (close - enterLong) / enterLong * 100
                result_df = add_result(result_df, result, 'stop loss', time)
                enterLong = stopLong = 0.0
                first_take_close = False
                second_take_close = False
                if first_stop:
                    wait_sma_cross = True

            # если не отстопило, проверяем на условия закрытия по тейку
            else:
                bb1_up = spread_df.iloc[index]['bb1_up']
                bb1_down = spread_df.iloc[index]['bb1_down']
                if first_take_close:
                    if second_take_close:
                        # смотрим последний уровень закрытия
                        if close < bb1_down and enterShort > 0.0:
                            # полностью закрываем шорт
                            inPosition = False
                            result = ((enterShort - close) / enterShort * 100)/3
                            # result = 0.0
                            result_df = add_result(result_df, result, '3rd take', time)
                            enterShort = stopShort = 0.0
                            first_take_close = False
                            second_take_close = False
                            first_stop = False
                        elif close > bb1_up and enterLong > 0.0:
                            inPosition = False
                            result = ((close - enterLong) / enterLong * 100)/3
                            # result = 0.0
                            result_df = add_result(result_df, result, '3rd take', time)
                            enterLong = stopLong = 0.0
                            first_take_close = False
                            second_take_close = False
                            first_stop = False
                    else:
                        if close < sma and enterShort > 0.0:
                            # берем треть от профита, т.к. закрыли бы только треть объема
                            result = ((enterShort - close) / enterShort * 100)/2
                            # result = 0.0
                            result_df = add_result(result_df, result, '2nd take', time)
                            stopShort = bb1_up
                            second_take_close = True
                            first_stop = False
                        elif close > sma and enterLong > 0.0:
                            result = ((close - enterLong) / enterLong * 100)/2
                            # result = 0.0
                            result_df = add_result(result_df, result, '2nd take', time)
                            stopLong = bb1_down
                            second_take_close = True
                            first_stop = False
                else:
                    if close < bb1_up and enterShort > 0.0:
                        # берем треть от профита, т.к. закрыли бы только треть объема
                        result = ((enterShort - close) / enterShort * 100) / 3
                        # result = 0.0
                        result_df = add_result(result_df, result, '1st take', time)
                        first_take_close = True
                        stopShort = bb3_up
                        first_stop = False
                    elif close > bb1_down and enterLong > 0.0:
                        result = ((close - enterLong) / enterLong * 100) / 3
                        # result = 0.0
                        result_df = add_result(result_df, result, '1st take', time)
                        first_take_close = True
                        stopLong = bb3_down
                        first_stop = False

    result_df.to_csv(r'.\reports\sber_sberp_result.csv', index=False, sep="\t")
    max_loss = result_df['result'].min()

    total = result_df['result'].sum()
    print(result_df)
    print(max_loss)
    print(total)


def test_oc_str_2takes(coin1, coin2, startdate, take_file):
    # получение исходных данных
    if take_file:
        filepath_check = r'.\files\sber_sberp.csv'
        spread_df = pd.read_csv(filepath_check, sep=",")
        spread_df.drop(["bb1.dn","bb1.up","bb3.dn","bb3.up","bb4.dn","bb4.up","MA"], axis=1, inplace=True)
    else:
        connection = modul.connect_to_sqlalchemy()
        end = datetime.datetime.now().timestamp()
        df_coin1 = modul.get_sql_history_price(coin1, connection, startdate, end)
        df_coin2 = modul.get_sql_history_price(coin2, connection, startdate, end)
        spread_df = modul.make_spread_df(df_coin1, df_coin2, last_to_end=False, tf=tf_5m)

    spread_df['bb1_up'], spread_df['sma'],spread_df['bb1_down'], = talib.BBANDS(spread_df.close, 240, 1, 1, 0)
    spread_df['bb3_up'], aaa, spread_df['bb3_down'] = talib.BBANDS(spread_df.close, 240, 3, 3, 0)
    spread_df['bb4_up'], bbb, spread_df['bb4_down'] = talib.BBANDS(spread_df.close, 240, 4.2, 4.2, 0)

    # определелим переменные для расчетов
    result_df = pd.DataFrame(columns=['position', 'result', 'time'])
    inPosition = False
    first_take_close = False
    # second_take_close = False
    enterShort = 0.0
    enterLong = 0.0
    stopShort = 0.0
    stopLong = 0.0
    # open_price = 0.0
    wait_sma_cross = False
    first_stop = False
    # result = 0.0
    for index in range(len(spread_df)):
        # вынем из дф нужные данные в переменные
        close = spread_df.iloc[index]['close']
        time =  spread_df.iloc[index]['time']
        if index > 240:
            close_before = spread_df.iloc[index-1]['close']
        else:
            close_before = 0.0
        bb3_up = spread_df.iloc[index]['bb3_up']
        bb3_down = spread_df.iloc[index]['bb3_down']
        sma = spread_df.iloc[index]['sma']
        # Проверим, есть ли пересечение сма, если нам нужно его дождаться
        if wait_sma_cross:
            if (close_before < sma < close) |(close_before > sma > close):
                wait_sma_cross = False

        # сначала смотрим условия для открытия позиции
        if not inPosition and not wait_sma_cross:
            if close_before > bb3_up > close:
                # открываем позицию в шорт
                enterShort = close
                stopShort = spread_df.iloc[index]['bb4_up']
                first_stop = True
                result_df = add_result(result_df, 0.0, 'open short', time)
                inPosition = True
            elif close > bb3_down > close_before and close_before != 0:
                enterLong = close
                stopLong = spread_df.iloc[index]['bb4_down']
                first_stop = True
                result_df = add_result(result_df, 0.0, 'open long', time)
                inPosition = True
        else:
            # сначала проверяем на условие стоп лосса
            if close > stopShort and stopShort != 0.0:
                # закрываемся
                inPosition = False
                result = (enterShort - close) / enterShort * 100
                if first_take_close:
                    result = result/2
                result_df = add_result(result_df, result, 'stop loss', time)
                enterShort = stopShort = 0.0
                first_take_close = False
                second_take_close = False
                if first_stop:
                    wait_sma_cross = True
            elif close < stopLong:
                inPosition = False
                result = (close - enterLong) / enterLong * 100
                if first_take_close:
                    result = result/2
                result_df = add_result(result_df, result, 'stop loss', time)
                enterLong = stopLong = 0.0
                first_take_close = False
                second_take_close = False
                if first_stop:
                    wait_sma_cross = True

            # если не отстопило, проверяем на условия закрытия по тейку
            else:
                bb1_up = spread_df.iloc[index]['bb1_up']
                bb1_down = spread_df.iloc[index]['bb1_down']
                if first_take_close:
                    # if second_take_close:
                        # смотрим последний уровень закрытия
                    #     if close < bb1_down and enterShort > 0.0:
                    #         # полностью закрываем шорт
                    #         inPosition = False
                    #         result = ((enterShort - close) / enterShort * 100)/3
                    #         # result = 0.0
                    #         result_df = add_result(result_df, result, '3rd take', time)
                    #         enterShort = stopShort = 0.0
                    #         first_take_close = False
                    #         second_take_close = False
                    #         first_stop = False
                    #     elif close > bb1_up and enterLong > 0.0:
                    #         inPosition = False
                    #         result = ((close - enterLong) / enterLong * 100)/3
                    #         # result = 0.0
                    #         result_df = add_result(result_df, result, '3rd take', time)
                    #         enterLong = stopLong = 0.0
                    #         first_take_close = False
                    #         second_take_close = False
                    #         first_stop = False
                    # else:
                    if close < sma and enterShort > 0.0:
                        # берем треть от профита, т.к. закрыли бы только треть объема
                        result = ((enterShort - close) / enterShort * 100)/2
                        # result = 0.0
                        result_df = add_result(result_df, result, '2nd take', time)
                        inPosition = False
                        enterShort = stopShort = 0.0
                        first_take_close = False
                        # second_take_close = True
                        first_stop = False
                    elif close > sma and enterLong > 0.0:
                        result = ((close - enterLong) / enterLong * 100)/2
                        # result = 0.0
                        result_df = add_result(result_df, result, '2nd take', time)
                        inPosition = False
                        enterLong = stopLong = 0.0
                        first_take_close = False
                        # second_take_close = True
                        first_stop = False
                else:
                    if close < bb1_up and enterShort > 0.0:
                        # берем треть от профита, т.к. закрыли бы только треть объема
                        result = ((enterShort - close) / enterShort * 100) / 2
                        # result = 0.0
                        result_df = add_result(result_df, result, '1st take', time)
                        first_take_close = True
                        stopShort = enterShort
                        first_stop = False
                    elif close > bb1_down and enterLong > 0.0:
                        result = ((close - enterLong) / enterLong * 100) / 2
                        # result = 0.0
                        result_df = add_result(result_df, result, '1st take', time)
                        first_take_close = True
                        stopLong = enterLong
                        first_stop = False

    result_df.to_csv(r'.\reports\sber_sberp_result.csv', index=False, sep="\t")
    max_loss = result_df['result'].min()

    total = result_df['result'].sum()
    print(result_df)
    print(max_loss)
    print(total)

start_time = datetime.datetime.now().timestamp() - 10000 * tf_5m
# test_oc_strategy('AAVEUSDT', 'AXSUSDT', start_time, True)
test_oc_str_2takes('AAVEUSDT', 'AXSUSDT', start_time, True)